import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from './components/ui/card';
import { Button } from './components/ui/button';
import { Alert, AlertDescription, AlertTitle } from './components/ui/alert';
import { Shield, Wallet, Gamepad, Key, Lock, History, AlertCircle, Home, ChevronRight, Trophy, Star } from 'lucide-react';

const HomePage = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-violet-50 to-white">
      <div className="max-w-6xl mx-auto p-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-violet-600 to-indigo-600">
            Welcome to DIV Gaming
          </h1>
          <p className="text-lg text-gray-600 mb-8">Your secure gateway to age-appropriate gaming</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer" onClick={() => onNavigate('wallet')}>
            <CardContent className="p-6">
              <div className="mb-4 bg-violet-100 rounded-full w-12 h-12 flex items-center justify-center group-hover:bg-violet-200 transition-colors">
                <Wallet className="h-6 w-6 text-violet-600" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Identity Wallet</h2>
              <p className="text-gray-600">Manage your secure digital identity and verifications</p>
              <ChevronRight className="h-5 w-5 text-violet-500 mt-4 group-hover:translate-x-2 transition-transform" />
            </CardContent>
          </Card>

          <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer" onClick={() => onNavigate('games')}>
            <CardContent className="p-6">
              <div className="mb-4 bg-indigo-100 rounded-full w-12 h-12 flex items-center justify-center group-hover:bg-indigo-200 transition-colors">
                <Gamepad className="h-6 w-6 text-indigo-600" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Game Library</h2>
              <p className="text-gray-600">Explore our collection of age-appropriate games</p>
              <ChevronRight className="h-5 w-5 text-indigo-500 mt-4 group-hover:translate-x-2 transition-transform" />
            </CardContent>
          </Card>

          <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer" onClick={() => onNavigate('history')}>
            <CardContent className="p-6">
              <div className="mb-4 bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                <History className="h-6 w-6 text-blue-600" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Activity History</h2>
              <p className="text-gray-600">Track your gaming and verification history</p>
              <ChevronRight className="h-5 w-5 text-blue-500 mt-4 group-hover:translate-x-2 transition-transform" />
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 bg-gradient-to-r from-violet-100 to-indigo-100 rounded-2xl p-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-semibold mb-2">Get Started Today</h3>
              <p className="text-gray-600">Create your secure wallet and start gaming safely</p>
            </div>
            <Button 
              className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
              onClick={() => onNavigate('wallet')}
            >
              Create Wallet
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

const WalletPage = ({ activeWallet, onCreateWallet, onNavigate }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-violet-50 to-white p-8">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6 hover:bg-violet-100"
          onClick={() => onNavigate('home')}
        >
          <Home className="h-4 w-4 mr-2" /> Back to Home
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl mb-2">Digital Identity Wallet</CardTitle>
                <CardDescription>Secure and private age verification</CardDescription>
              </div>
              {activeWallet && (
                <div className="bg-green-100 text-green-600 px-4 py-2 rounded-full text-sm font-medium flex items-center">
                  <Shield className="h-4 w-4 mr-2" /> Active
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!activeWallet ? (
              <div className="text-center py-12">
                <div className="bg-violet-100 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <Lock className="h-8 w-8 text-violet-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Create Your Wallet</h3>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">
                  Set up your secure digital identity wallet to access age-appropriate gaming content
                </p>
                <Button 
                  className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                  onClick={onCreateWallet}
                >
                  Get Started
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                <Alert className="bg-violet-50 border-violet-200">
                  <Shield className="h-4 w-4 text-violet-600" />
                  <AlertTitle>Wallet Secure</AlertTitle>
                  <AlertDescription>
                    Your digital identity is protected and ready for verification
                  </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="bg-gradient-to-br from-violet-50 to-indigo-50">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="bg-white rounded-full p-2">
                          <Key className="h-5 w-5 text-violet-600" />
                        </div>
                        <h4 className="font-semibold">Verification Status</h4>
                      </div>
                      <p className="text-sm text-gray-600">Ready for age verification</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-indigo-50 to-blue-50">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="bg-white rounded-full p-2">
                          <Shield className="h-5 w-5 text-indigo-600" />
                        </div>
                        <h4 className="font-semibold">Security Level</h4>
                      </div>
                      <p className="text-sm text-gray-600">Maximum Protection</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {activeWallet && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest wallet interactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="bg-green-100 rounded-full p-2">
                    <Shield className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Wallet Activated</p>
                    <p className="text-sm text-gray-600">Today at {new Date().toLocaleTimeString()}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

const GamesPage = ({ games, onGameSelect, verificationStatus, selectedGame, onNavigate }) => {
  const [hoveredGame, setHoveredGame] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white p-8">
      <div className="max-w-6xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6 hover:bg-indigo-100"
          onClick={() => onNavigate('home')}
        >
          <Home className="h-4 w-4 mr-2" /> Back to Home
        </Button>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Game Library</h1>
          <p className="text-gray-600">Discover and play games suited for you</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game) => (
            <Card 
              key={game.id}
              className={`group cursor-pointer transform transition-all duration-300 hover:shadow-xl ${
                hoveredGame === game.id ? 'scale-105' : ''
              }`}
              onClick={() => onGameSelect(game)}
              onMouseEnter={() => setHoveredGame(game.id)}
              onMouseLeave={() => setHoveredGame(null)}
            >
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-gradient-to-br from-indigo-100 to-violet-100 rounded-full p-3">
                    {game.type === 'Casino' && <Trophy className="h-6 w-6 text-indigo-600" />}
                    {game.type === 'Sports' && <Gamepad className="h-6 w-6 text-violet-600" />}
                    {game.type === 'Casual' && <Star className="h-6 w-6 text-blue-600" />}
                    {game.type === 'Arcade' && <Trophy className="h-6 w-6 text-purple-600" />}
                  </div>
                  {game.ageRestricted && (
                    <div className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-sm">
                      18+
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-semibold mb-2 group-hover:text-indigo-600 transition-colors">
                  {game.name}
                </h3>
                <p className="text-gray-600">{game.type}</p>
                <div className="mt-4 flex items-center text-sm text-gray-500">
                  <Button 
                    variant="ghost" 
                    className="p-0 hover:bg-transparent hover:text-indigo-600"
                  >
                    Play Now <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {verificationStatus === 'underage' && (
          <Alert className="mt-8 bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-500" />
            <AlertTitle>Age Restricted Content</AlertTitle>
            <AlertDescription>
              {selectedGame?.name} requires users to be 18 or older. You have been redirected to age-appropriate games.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
};

const DIVPlatform = () => {
  const [activeWallet, setActiveWallet] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [selectedGame, setSelectedGame] = useState(null);
  const [currentPage, setCurrentPage] = useState('home');

  const games = [
    { id: 1, name: "Poker Stars", type: "Casino", ageRestricted: true },
    { id: 2, name: "Fantasy Cricket", type: "Sports", ageRestricted: true },
    { id: 3, name: "Puzzle Quest", type: "Casual", ageRestricted: false },
    { id: 4, name: "Skill Games", type: "Arcade", ageRestricted: false },
    { id: 5, name: "Adventure Quest", type: "Casual", ageRestricted: false },
    { id: 6, name: "Sports Betting", type: "Sports", ageRestricted: true }
  ];

  const handleCreateWallet = () => {
    setActiveWallet(true);
  };

  const handleVerification = () => {
    setTimeout(() => {
      setVerificationStatus('underage');
    }, 1000);
  };

  const handleGameSelect = (game) => {
    setSelectedGame(game);
    if (game.ageRestricted) {
      handleVerification();
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'wallet':
        return (
          <WalletPage 
            activeWallet={activeWallet} 
            onCreateWallet={handleCreateWallet}
            onNavigate={setCurrentPage}
          />
        );
      case 'games':
        return (
          <GamesPage 
            games={games}
            onGameSelect={handleGameSelect}
            verificationStatus={verificationStatus}
            selectedGame={selectedGame}
            onNavigate={setCurrentPage}
          />
        );
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderPage()}
    </div>
  );
};

export default DIVPlatform;