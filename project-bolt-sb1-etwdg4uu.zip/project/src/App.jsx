import DIVPlatform from './DIVPlatform'

function App() {
  return <DIVPlatform />
}

export default App